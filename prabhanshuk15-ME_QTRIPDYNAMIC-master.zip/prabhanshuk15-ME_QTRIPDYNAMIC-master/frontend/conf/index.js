
const config = { backendEndpoint: "http://13.235.93.171:8082" };
// const config = { backendEndpoint: "http://65.0.40.89:8082" };

export default config;
